/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package aulajplay;

import jplay.GameImage;
import jplay.Window;

/**
 *
 * @author lcc
 */
public class Exemplo2GameImage {

    public static void main(String[] args) {
        // TODO code application logic here
        Window janela = new Window(800,600);
        GameImage fundo = new GameImage("fundo.jpg");

        fundo.draw();
        janela.update();
    }
}
