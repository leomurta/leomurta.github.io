/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package aulajplay;

import jplay.GameImage;
import jplay.Keyboard;
import jplay.Mouse;
import jplay.Window;


/**
 *
 * @author lcc
 */
public class Exemplo4Mouse {

    public static void main(String[] args) {
        Window janela = new Window(800, 600);
        Keyboard keyboard = janela.getKeyboard();
        GameImage backGround = new GameImage("fundo.jpg");

        GameImage img = new GameImage("img.png");
        img.x = 10;
        img.y = 10;

        boolean executando = true;
        while (executando) {

            Mouse mouse = janela.getMouse();

            if(mouse.isLeftButtonPressed()){
                img.x = mouse.getPosition().x;
                img.y = mouse.getPosition().y;
            }

            if (mouse.isOverObject(img)){
                backGround.loadImage("fundo2.jpg");
            }else{
                backGround.loadImage("fundo.jpg");
            }

            if (keyboard.keyDown(Keyboard.ESCAPE_KEY)) {
                executando = false;
            }

            backGround.draw();
            img.draw();
            janela.update();

        }
        janela.exit();
    }
}
