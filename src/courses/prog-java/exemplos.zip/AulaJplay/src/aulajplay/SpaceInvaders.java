/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package aulajplay;

import jplay.GameImage;
import jplay.Keyboard;
import jplay.Sprite;
import jplay.Window;

/**
 *
 * @author Alessandro
 */
public class SpaceInvaders {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Window janela = new Window(800, 600);
        Keyboard keyboard = janela.getKeyboard();
        GameImage fundo = new GameImage("fundo.jpg");
        boolean executando = true;

        //Criando a nave
        Sprite boneco = new Sprite("nave.png", 2);
        boneco.x = 50;
        boneco.y = 300;
        
        //Criando o vetor de tiros
        Sprite[] tiros = new Sprite[50];
        int numeroDeTiros = 0;

        //Criando o vetor de inimigos
        int posInicial = 0;
        Sprite[] inimigos = new Sprite[15];
        for (int i = 0; i < inimigos.length; i++) {
            inimigos[i] = new Sprite("monstro.png", 2);
            inimigos[i].y = 2;
            inimigos[i].x = posInicial + i * 40;
        }
        boolean moveDir = true;
        
        while (executando) {
            //Verifica se a tecla ESC foi pressionada
            if (keyboard.keyDown(Keyboard.ESCAPE_KEY)) {
                executando = false;
            }
            
            //Verifica se ainda existem inimigos
            executando = false;
            for (int i = 0; i < inimigos.length; i++) {
                if (inimigos[i]!=null){
                    executando = true;
                }                
            }

            //Verifica se o usuário atirou
            if (keyboard.keyDown(Keyboard.SPACE_KEY)) {
                tiros[numeroDeTiros] = new Sprite("tiro.png");
                tiros[numeroDeTiros].y = boneco.y;
                tiros[numeroDeTiros].x = boneco.x + boneco.width / 2;
                numeroDeTiros++;
            }
                        
            //Modifica a posição dos inimigos
            if (moveDir){
                if(posInicial>200){
                    moveDir = false;
                }else{
                    posInicial++;
                }
            }else{
                if(posInicial<1){
                    moveDir = true;
                }else{
                    posInicial--;
                }
            }
            for (int i = 0; i < inimigos.length; i++) {
                if (inimigos[i]!=null){
                    inimigos[i].x = posInicial + i * 40;
                }
            }
            
            //Verifica se o tiro atingiu algum inimigo 
            //ou se o tiro chegou no fim da tela
            for (int i = 0; i < numeroDeTiros; i++) {                
                tiros[i].moveTo(tiros[i].x, 0, 10);
                
                for (int j = 0; j < inimigos.length; j++) {
                    if (inimigos[j] != null) {
                        if (tiros[i].collided(inimigos[j])) {
                            inimigos[j] = null;
                        }
                    }
                }
                if (tiros[i].y < 10) {
                    for (int j = i; j < numeroDeTiros - 1; j++) {
                        tiros[j] = tiros[j + 1];
                    }
                    numeroDeTiros--;
                }
            }
            
            //Move o nave
            boneco.moveX(5);
            boneco.moveY(5);
            
            //Desenha todas animações            
            fundo.draw();
            for (int i = 0; i < numeroDeTiros; i++) {
                tiros[i].draw();
            }
            for (int i = 0; i < inimigos.length; i++) {
                if (inimigos[i] != null) {
                    inimigos[i].draw();
                    inimigos[i].update();
                }
            }
            boneco.update();
            boneco.draw();
            janela.update();
            janela.delay(50);
        }        
        fundo.loadImage("fim.png");
        fundo.draw();
        janela.update();
        janela.delay(4000);
        janela.exit();
    }
}
