/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package aulajplay;

import java.awt.Color;
import jplay.GameImage;
import jplay.Keyboard;
import jplay.Sprite;
import jplay.Window;

/**
 *
 * @author lcc
 */
public class Exemplo6Colisoes {

    public static void main(String[] args) {
        Window janela = new Window(800, 600);
        Keyboard keyboard = janela.getKeyboard();
        GameImage backGround = new GameImage("fundo.jpg");

        //Criando a nave
        Sprite boneco = new Sprite("nave.png", 2);
        boneco.setTotalDuration(300);
        boneco.x = 50;
        boneco.y = 500;

        //Criando o tiro
        Sprite tiro = new Sprite("tiro.png");

        //Criando inimigo
        Sprite inimigo = new Sprite("monstro.png", 2);
        inimigo.setTotalDuration(300);
        inimigo.y = 2;
        inimigo.x = 600;


        boolean executando = true;
        while (executando) {

            //Move o nave
            boneco.moveX(5);
            boneco.moveY(5);

            if (inimigo.x>500){
                inimigo.x = 100;
            }else{
                inimigo.moveTo(501, inimigo.y, 3);
            }

            //Verifica se o usuário atirou
            if (keyboard.keyDown(Keyboard.SPACE_KEY)) {
                tiro = new Sprite("tiro.png");
                tiro.y = boneco.y;
                tiro.x = boneco.x + boneco.width / 2;
            }

            if (tiro != null) {
                //move o tiro
                tiro.moveTo(tiro.x, 0, 10);

                //Verifica se o tiro chegou no final da tela
                if (tiro.y < 1) {
                    tiro = null;
                }
            }


            if (keyboard.keyDown(Keyboard.ESCAPE_KEY)) {
                executando = false;
            }

            janela.delay(10);
            backGround.draw();
            inimigo.update();
            inimigo.draw();
            boneco.update();
            boneco.draw();
            if (tiro != null) {
                if (tiro.collided(inimigo)){
                    janela.delay(200);
                    janela.drawText("OUCH", 200, 100, Color.RED);
                }
                tiro.draw();
            }
            janela.update();

        }
        janela.exit();
    }
}
