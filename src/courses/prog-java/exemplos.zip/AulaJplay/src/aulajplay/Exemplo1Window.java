/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package aulajplay;

import jplay.Window;

/**
 *
 * @author lcc
 */
public class Exemplo1Window {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Window janela = new Window(800,600);        
    }

}
