/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package aulajplay;

import jplay.GameImage;
import jplay.Keyboard;
import jplay.Window;


/**
 *
 * @author lcc
 */
public class Exemplo3Teclado {

  public static void main(String[] args)
    {
        Window janela = new Window(800,600);
        Keyboard keyboard = janela.getKeyboard();
        GameImage backGround = new GameImage("fundo.jpg");

        boolean executando = true;
        while(executando)
        {
                backGround.draw();
                janela.update();

                if (keyboard.keyDown(Keyboard.ESCAPE_KEY) )
                    executando = false;
        }
        janela.exit();
    }
}
